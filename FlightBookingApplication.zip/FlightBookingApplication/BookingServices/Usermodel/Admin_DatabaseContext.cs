﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace BookingServices.Usermodel
{
    public partial class Admin_DatabaseContext : DbContext
    {
        public Admin_DatabaseContext()
        {
        }

        public Admin_DatabaseContext(DbContextOptions<Admin_DatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AdminCredentials> AdminCredentials { get; set; }
        public virtual DbSet<AirlineaddBlock> AirlineaddBlock { get; set; }
        public virtual DbSet<Flights> Flights { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=CTSDOTNET104;Database=Admin_Database;User id =sa;password=pass@word1");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AdminCredentials>(entity =>
            {
                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AirlineaddBlock>(entity =>
            {
                entity.Property(e => e.AirlineId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Airlinename)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Flights>(entity =>
            {
                entity.Property(e => e.Bcseats).IsUnicode(false);

                entity.Property(e => e.Destination)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.FlightId)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Flightlogo).IsUnicode(false);

                entity.Property(e => e.Flightname)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Ncbseats).IsUnicode(false);

                entity.Property(e => e.Price).IsUnicode(false);

                entity.Property(e => e.ScheduledDays).IsUnicode(false);

                entity.Property(e => e.Source)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.StartTime).HasColumnType("datetime");
            });
        }
    }
}
